
# -- Rental experiment

	library(reshape2)
	library(ggplot2)

	#load data
	fpath = ... #file path where data is saved
	dataset <- readRDS(paste0(fpath, "rental_data.rds")) #load data

	dch = droplevels(subset(dataset, (stage == "choice"))) #choice data
	dfr = droplevels(subset(dataset, (stage == "freeresp"))) #free response data
	dfr$responses[is.na(dfr$responses)] <- ""
	dch_rtch = dch[(dch$rt/1000/60 >= 0.5) & (nchar(dfr$responses) >= 10),] #exclude
	otbl_rtch = table(dch_rtch$responses, dch_rtch$condition) #contingency table
	tbl_rtch = prop.table(otbl_rtch, 2) #proportions in each experimental condition
	
	#create table with response proportions
	meltbl = melt(tbl_rtch)
	names(meltbl) = c("response", "condition", "count")
	meltbl$response[meltbl$response == 0] <- "More likely"
	meltbl$response[meltbl$response == 1] <- "Equally likely"
	meltbl$response[meltbl$response == 2] <- "Less likely"
	meltbl$response <- factor(meltbl$response, levels = c("Less likely", "Equally likely", "More likely"))
	meltbl$condition <- factor(meltbl$condition, levels = c("Control", "Advertising Cap", "Difficult Maintenance"))

	#compute stacked error bars
	count_other = t(colSums(otbl_rtch) - t(otbl_rtch))
	count_table = merge(melt(otbl_rtch), melt(count_other), by = c("Var2", "Var1"))
	names(count_table) = c("condition", "response", "count_for", "count_against")
	error_table = data.frame(count_table, t(sapply(1:nrow(count_table), function(i) qbeta(c(.025, .975), 1/3 + count_table$count_for[i], 2/3 + count_table$count_against[i])))) #1/3 2/3 is for marginal beta from jeffreys prior on dirichlet
	names(error_table) = c(names(count_table), "lowCI", "highCI")
	error_table$response[error_table$response == 0] <- "More likely"
	error_table$response[error_table$response == 1] <- "Equally likely"
	error_table$response[error_table$response == 2] <- "Less likely"

	#merge tables
	all_table = merge(meltbl, error_table, c("condition", "response"))
	all_table[all_table$response == "Less likely", c("lowCI", "highCI")] = NA
	all_table[all_table$response == "Equally likely", c("lowCI", "highCI")] = all_table[all_table$response == "Equally likely", c("lowCI", "highCI")] + all_table[all_table$response == "More likely", "count"]
	levels(all_table$condition) <- gsub(" ", "\n", levels(all_table$condition))

	#plot attitude change proportions (Figure 4)
	pdf(paste0(fpath, "Fig4.pdf"), height = 5, width = 6)
		gplot2 <- ggplot(all_table, aes(x = condition, y = count, fill = response)) + geom_bar(stat = "identity") +
					geom_errorbar(aes(x = condition, ymax = highCI, ymin = lowCI), width = .1, col = "dimgray") +
					ggtitle(paste0("Effect of advertisement on choosing No. 2")) + #\nQuick responders removed (n = 2000 - 289)")) +
					geom_text(aes(label = round(count,3)), size = 5, position = position_stack(vjust = .5)) +
					scale_fill_manual("legend", values = c("Less likely" = "indianred2", "Equally likely" = "dodgerblue", "More likely" = "seagreen3")) +
					theme(text = element_text(size=16), axis.text.x = element_text(size=14), plot.margin=unit(c(5.5,5.5,5.5,25.5), "pt")) + labs(y = "Proportion")
		gplot2 #ignore 3 errorbar rows missing
	dev.off()

	#choice regression
	library(brms)
	dchf = dch_rtch
	dchf$responses = 3-as.numeric(dchf$responses)
	dchf$condition = factor(dchf$condition)
	dchf$condition = relevel(dchf$condition, ref = "Control")
	brolr = brm(responses ~ condition, data = dchf, family=cumulative("logit"), prior = set_prior("cauchy(0,2.5)", class = "b"), cores = 3)
	postsamb = posterior_samples(brolr)
	colMeans(postsamb[,3:4] < 0)
	apply(postsamb[,3:4], 2, quantile, probs = c(0.025, 0.975))

	#single condition model comparisons
	brolr_AC = brm(responses ~ condition, data = subset(dchf, condition %in% c("Control", "Advertising Cap")), family=cumulative("logit"), prior = set_prior("cauchy(0,2.5)", class = "b"), cores = 3)
	brolr_AC_null = brm(responses ~ 1, data = subset(dchf, condition %in% c("Control", "Advertising Cap")), family=cumulative("logit"), cores = 3)
	brolr_DM = brm(responses ~ condition, data = subset(dchf, condition %in% c("Control", "Difficult Maintenance")), family=cumulative("logit"), prior = set_prior("cauchy(0,2.5)", class = "b"), cores = 3)
	brolr_DM_null = brm(responses ~ 1, data = subset(dchf, condition %in% c("Control", "Difficult Maintenance")), family=cumulative("logit"), cores = 3)
	#WAIC
	waic(brolr_AC, brolr_AC_null)
	waic(brolr_DM, brolr_DM_null)
	
	
	#-Free response
	
	library(readxl)    
	read_excel_allsheets <- function(filename) {
		sheets <- readxl::excel_sheets(filename)
		x <-    lapply(sheets, function(X) readxl::read_excel(filename, sheet = X))
		names(x) <- sheets
		x
	}

	frcat <- read_excel_allsheets(paste0(fpath, "rental-freeresp.xlsx"))
	
	dnames = list(c("More likely", "Equally likely", "Less likely"), c("Control", "Advertising Cap", "Difficult Maintenance"))

	frsnum = lapply(c("Control","Advertising Cap","Difficult Maintenance"), function(cond) lapply(0:2, function(choice) subset(dfr, condition == cond)$individual[subset(dch, condition == cond)$response == choice]))
	names(frsnum) <- c("Control", "Advertising Cap", "Difficult Maintenance")
	names(frsnum$"Control") <- names(frsnum$"Advertising Cap") <- names(frsnum$"Difficult Maintenance") <- c("More likely", "Equally likely", "Less likely")

	included = which((dch$rt/1000/60 >= 0.5) & (nchar(dfr$responses) >= 10))
	frsinclude = lapply(1:9, function(crs) frsnum[[1 + floor((crs-1)/3)]][[1 + ((crs-1) %% 3)]] %in% included)
	sizes = colSums(matrix(sapply(1:9, function(cr) sum(frsinclude[[cr]])), nrow = 3, ncol = 3, byrow = F, dimnames = dnames))
	full_sizes = colSums(matrix(sapply(1:9, function(cr) nrow(frcat[[cr]])), nrow = 3, ncol = 3, byrow = F, dimnames = dnames))

	#References to Advertising (in favor of #2)
	refad = matrix(sapply(1:9, function(cr) sum(frcat[[cr]][frsinclude[[cr]],1] == 1, na.rm=T)), nrow = 3, ncol = 3, byrow = F, dimnames = dnames)
	#References to Maintenance (in favor of #1)
	refmain = matrix(sapply(1:9, function(cr) sum(frcat[[cr]][frsinclude[[cr]],2] == 1, na.rm=T)), nrow = 3, ncol = 3, byrow = F, dimnames = dnames)

	# Core wrapping function
	wrap.it <- function(x, len)
	{ 
	  sapply(x, function(y) paste(strwrap(y, len), 
								  collapse = "\n"), 
			 USE.NAMES = FALSE)
	}
	# Call this function with a list or vector
	wrap.labels <- function(x, len)
	{
	  if (is.list(x))
	  {
		lapply(x, wrap.it, len)
	  } else {
		wrap.it(x, len)
	  }
	}

	refnames = colnames(refad)
	wraprefnames = wrap.labels(refnames, 1)
	wraprefnames[1] = paste0(wraprefnames[1], "\n")
	
	ref_props = 100*c(colSums(refad)/sizes, NA, colSums(refmain)/sizes)
	ref_error = cbind(sapply(1:length(sizes), function(i) qbeta(c(0.025, 0.975), 1/2 + colSums(refad)[i], 1/2 + sizes[i] - colSums(refad)[i])), matrix(rep(NA,2), nrow = 2), sapply(1:length(sizes), function(i) qbeta(c(0.025, 0.975), 1/2 + colSums(refmain)[i], 1/2 + sizes[i] - colSums(refmain)[i])))
	
	error.bar <- function(x, y, upper, lower=upper, length=0.05, col=1) { arrows(x,y+upper, x, y-lower, angle=90, code=3, length=length, col=col) }

	#plot free response proportions (Figure 6)
	pdf(paste0(fpath, "Fig6.pdf"), width = 10, height = 6)
		par(mar = c(5.1,4.1,4.1,2.1) + c(0,.3,-3,0))
		cex = 1.5
		refbar <- barplot(ref_props, ylim = c(0,3.5), ylab = "Frequency of free response reasoning (%)", xlab = "", border = F, cex.axis = cex, cex.names = cex, cex.lab = cex, names.arg = "")
		error.bar(refbar, 0, ref_error[2,]*100, -ref_error[1,]*100)
		mtext(text = c(wraprefnames, NA, wraprefnames), side = 1, at = refbar, line = 2, cex = cex)
		mtext(text = "Condition", side = 1, line = 4, cex = cex)
		text(refbar[2], 3.3, '"No. 2 has \n less advertising"', cex = cex)
		text(refbar[6], 3.3, '"No. 2 has \n fewer resources"', cex = cex)
	dev.off()

	#free response regressions
	unlistfrcatAd = unlist(lapply(1:9, function(cr) unlist(frcat[[cr]][,1])))
	unlistfrcatMain = unlist(lapply(1:9, function(cr) unlist(frcat[[cr]][,2])))
	refrcat = data.frame(RefAd = unlistfrcatAd, RefMain = unlistfrcatMain, condition = c(rep("Control", full_sizes[1]), rep("Advertising Cap", full_sizes[2]), rep("Difficult Maintenance", full_sizes[3])))
	refrcat[is.na(refrcat)] <- 0
	refrcat[refrcat == -1] <- 0
	refrcat$individual <- unlist(frsnum)
	
	#free response regression, Ad, all conditions
	refrcat$condition <- relevel(refrcat$condition, ref = "Advertising Cap")
	blogitRefAd_brm = brm(RefAd ~ condition, data = subset(refrcat, individual %in% included), family=bernoulli(link="logit"), prior = set_prior("cauchy(0,2.5)", class = "b"), cores = 3)
	simbApost_brm = posterior_samples(blogitRefAd_brm)
	colMeans(simbApost_brm[,2:3] > 0)

	#single condition model comparisons
	#AC vs CON only
	blogitRefAd_CON_brm = brm(RefAd ~ condition, data = subset(refrcat, (individual %in% included) & (condition %in% c("Control", "Advertising Cap"))), family=bernoulli(link="logit"), prior = set_prior("cauchy(0,2.5)", class = "b"), cores = 3, iter = 4000)
	blogitRefAd_CON_null_brm = brm(RefAd ~ 1, data = subset(refrcat, (individual %in% included) & (condition %in% c("Control", "Advertising Cap"))), family=bernoulli(link="logit"), cores = 3)
	#AC vs DM only
	blogitRefAd_DM_brm = brm(RefAd ~ condition, data = subset(refrcat, (individual %in% included) & (condition %in% c("Difficult Maintenance", "Advertising Cap"))), family=bernoulli(link="logit"), prior = set_prior("cauchy(0,2.5)", class = "b"), cores = 3, iter = 4000)
	blogitRefAd_DM_null_brm = brm(RefAd ~ 1, data = subset(refrcat, (individual %in% included) & (condition %in% c("Difficult Maintenance", "Advertising Cap"))), family=bernoulli(link="logit"), cores = 3)
	#WAIC
	waic(blogitRefAd_CON_brm, blogitRefAd_CON_null_brm)
	waic(blogitRefAd_DM_brm, blogitRefAd_DM_null_brm)

	#free response regression, Main, all conditions
	refrcat$condition <- relevel(refrcat$condition, ref = "Difficult Maintenance")
	blogitRefMain_brm = brm(RefMain ~ condition, data = subset(refrcat, individual %in% included), family=bernoulli(link="logit"), prior = set_prior("cauchy(0,2.5)", class = "b"), cores = 3)
	simbDpost_brm = posterior_samples(blogitRefMain_brm)
	colMeans(simbDpost_brm[,2:3] < 0)

	#single condition model comparisons
	#DM vs CON only
	blogitRefMain_CON_brm = brm(RefMain ~ condition, data = subset(refrcat, (individual %in% included) & (condition %in% c("Control", "Difficult Maintenance"))), family=bernoulli(link="logit"), prior = set_prior("cauchy(0,2.5)", class = "b"), cores = 3)
	blogitRefMain_CON_null_brm = brm(RefMain ~ 1, data = subset(refrcat, (individual %in% included) & (condition %in% c("Control", "Difficult Maintenance"))), family=bernoulli(link="logit"), cores = 3)
	#DM vs AC only
	blogitRefMain_AC_brm = brm(RefMain ~ condition, data = subset(refrcat, (individual %in% included) & (condition %in% c("Difficult Maintenance", "Advertising Cap"))), family=bernoulli(link="logit"), prior = set_prior("cauchy(0,2.5)", class = "b"), cores = 3)
	blogitRefMain_AC_null_brm = brm(RefMain ~ 1, data = subset(refrcat, (individual %in% included) & (condition %in% c("Difficult Maintenance", "Advertising Cap"))), family=bernoulli(link="logit"), cores = 3)
	#WAIC
	waic(blogitRefMain_CON_brm, blogitRefMain_CON_null_brm)
	waic(blogitRefMain_AC_brm, blogitRefMain_AC_null_brm)


	#honesty regression
	frcat2 = lapply(1:9, function(condx) frcat[[condx]][,3])
	wordsin = grepl("honest", dfr$responses[included])
	nansc = table(dfr$condition[included][wordsin][-c(2,3,16,18,54,77)]) #exclude c(2,3,16,18,54,77)
	ntotc = table(dfr$condition[included])
	dats = data.frame(Condition = c(rep("Control",ntotc[2]), rep("TrCap",ntotc[1]), rep("TrMnt",ntotc[3])), Ans = c(rep(0,ntotc[2]-nansc[2]),rep(1,nansc[2]),rep(0,ntotc[1]-nansc[1]),rep(1,nansc[1]),rep(0,ntotc[3]-nansc[3]),rep(1,nansc[3])))

	bg = bayesglm(Ans ~ Condition, data = dats)
	simbg = sim(bg, n.sims = 1e7)
	colMeans(coef(simbg) > 0)



# -- Review experiment

	library(stringr)
	library(jsonlite)
	library(reshape2)
	library(brms)
	library(Bolstad)

	#load data
	fpath = ... #file path where data is saved
	dataset <- readRDS(paste0(fpath, "review_data.rds")) #load data

	resps = as.character(subset(dataset, trial_type == 'survey-text')$responses)
	rts = subset(dataset, trial_type == 'survey-text')$rt/1000
	dats = t(sapply(resps, function(x) as.numeric(fromJSON(x))))
	rownames(dats) = 1:nrow(dats)
	#exclude people with answers outside of bounds
	exc = unique(rbind(which(dats[,c(1:3, 7:9)] < -100 | dats[,c(1:3, 7:9)] > 100, arr.ind=T), which(dats[,c(4:6, 10:12)] < 0 | dats[,c(4:6, 10:12)] > 100, arr.ind=T), which(is.na(dats), arr.ind=T))[,1])
	if (length(exc) > 0) { dats = dats[-exc,]; rts = rts[-exc] }

	#split up data
	datsA = dats[,1:3] #unspecified manufacturer
	fakeA = dats[,4:6]
	datsB = dats[,7:9] #retailer is manufacturer
	fakeB = dats[,10:12]
	x = c(3,4,5)
	
	#data means
	mn_datsA = colMeans(datsA)
	mn_datsB = colMeans(datsB)
	mn_fakeA = colMeans(fakeA)
	mn_fakeB = colMeans(fakeB)
	
	#data credible intervals (prior Cauchy(0,10))
	getCI = function(datx) { sapply(1:ncol(datx), function(i) quantile(coef(sim(bayesglm(datx[,i] ~ 1, prior.scale.for.intercept = 10), n.sims = 1e6)), c(0.025, 0.975))) }
	ci_datsA = getCI(datsA)
	ci_datsB = getCI(datsB)
	ci_fakeA = getCI(fakeA)
	ci_fakeB = getCI(fakeB)
	
	#plot data
	cols = c("dodgerblue", "indianred2")
	error.bar <- function(x, y, upper, lower=upper, length=0.05, col=1) { arrows(x,y+upper, x, y-lower, angle=90, code=3, length=length, col=col) }
	
	pdf(paste0(fpath, "Fig9.pdf"), width = 7, height = 3)

		layout(matrix(1:2, nrow = 1))
		par(mar = c(5.1,4.1,4.1,2.1) - c(1,0,3,0))

		plot(x, mn_datsA, type = "b", lty = "dashed", ylim = c(10,90), pch = 16, col = cols[1], xlab = "# of stars", ylab = "attitude change", xaxt = "n")
		axis(1, at = x)
		points(x, mn_datsB, type = "b", lty = "dashed", pch = 16, col = cols[2])
		error.bar(x, 0, upper = ci_datsA[2,], lower = -ci_datsA[1,], col = cols[1])
		error.bar(x, 0, upper = ci_datsB[2,], lower = -ci_datsB[1,], col = cols[2])
		legend("topleft", c("sold independently", "sold by manufacturer"), col = c(cols[1], cols[2]), pch = 16, bty = "n", pt.cex = 1, cex = .8)

		plot(x, mn_fakeA, type = "b", lty = "dashed", ylim = c(20,60), pch = 16, col = cols[1], xlab = "# of stars", ylab = "P(fake)", xaxt = "n")
		axis(1, at = x)
		points(x, mn_fakeB, type = "b", lty = "dashed", pch = 16, col = cols[2])
		error.bar(x, 0, upper = ci_fakeA[2,], lower = -ci_fakeA[1,], col = cols[1])
		error.bar(x, 0, upper = ci_fakeB[2,], lower = -ci_fakeB[1,], col = cols[2])

	dev.off()


	#regressions
	dats_att_df = rbind(cbind(melt(datsA), "retailer" = "unspec"), cbind(melt(datsB), "retailer" = "manufac"))
	names(dats_att_df) = c("Subject", "star_rating", "attitude_change", "retailer")
	dats_att_df$star_rating = x[dats_att_df$star_rating] - 3
	
	dats_fake_df = rbind(cbind(melt(fakeA), "retailer" = "unspec"), cbind(melt(fakeB), "retailer" = "manufac"))
	names(dats_fake_df) = c("Subject", "star_rating", "fake", "retailer")
	dats_fake_df$star_rating = x[dats_fake_df$star_rating] - 3

	dats_df = merge(dats_att_df, dats_fake_df, by = c("Subject", "star_rating", "retailer"), all.x = T)
	
	#attitude change
	brm_rev_att = brm(attitude_change ~ star_rating*retailer + (1 + star_rating*retailer | Subject), data = dats_df, cores = 3, control = list(max_treedepth = 15)) #adapt_delta = 0.99, 
	apply(posterior_samples(brm_rev_att, "b_"), 2, function(x) mean(x < 0))
	
	partial_sd_att = sqrt(mean(apply(cbind(datsA, datsB), 2, sd)^2))
	round(fixef(brm_rev_att)/partial_sd_att, 3) #standardized coefficients

	#fake
	brm_rev_fake = brm(fake ~ star_rating*retailer + (1 + star_rating*retailer | Subject), data = dats_df, cores = 3)
	apply(posterior_samples(brm_rev_fake, "b_"), 2, function(x) mean(x > 0))

	partial_sd_fake = sqrt(mean(apply(cbind(fakeA, fakeB), 2, sd)^2))
	round(fixef(brm_rev_fake)/partial_sd_fake, 3) #standardized coefficients


	#HDI + ROPE
	library(bayestestR)
	rope(brm_rev_att, range = c(-1,1), ci = 0.95, ci_method = "HDI", effects = "fixed")
	rope(brm_rev_fake, range = c(-1,1), ci = 0.95, ci_method = "HDI", effects = "fixed")
	
	#individual correlation between interaction coefficients
	brm_rev_att_coef_inter = coef(brm_rev_att)$Subject[,,"star_rating:retailermanufac"][,"Estimate"]
	brm_rev_fake_coef_inter = coef(brm_rev_fake)$Subject[,,"star_rating:retailermanufac"][,"Estimate"]
	library(BayesFactor)
	corBF = correlationBF(brm_rev_fake_coef_inter, brm_rev_att_coef_inter)
	corBF_samples = posterior(corBF, iterations = 10000)
	quantile(corBF_samples, c(.025, .975))
	
	#subgroups
	plot_all_subj = function(subj_plot, ylim_dats, ylim_fake) {
	
		mn_datsA_sp = colMeans(datsA[subj_plot,])
		mn_fakeA_sp = colMeans(fakeA[subj_plot,])
		mn_datsB_sp = colMeans(datsB[subj_plot,])
		mn_fakeB_sp = colMeans(fakeB[subj_plot,])
		ci_datsA_sp = getCI(datsA[subj_plot,])
		ci_fakeA_sp = getCI(fakeA[subj_plot,])
		ci_datsB_sp = getCI(datsB[subj_plot,])
		ci_fakeB_sp = getCI(fakeB[subj_plot,])

		plot(x, mn_datsA_sp, type = "b", lty = "dashed", ylim = ylim_dats, pch = 16, col = cols[1], xlab = "# of stars", ylab = "attitude change", xaxt = "n")
		axis(1, at = x)
		points(x, mn_datsB_sp, type = "b", lty = "dashed", pch = 16, col = cols[2])
		error.bar(x, 0, upper = ci_datsA_sp[2,], lower = -ci_datsA_sp[1,], col = cols[1])
		error.bar(x, 0, upper = ci_datsB_sp[2,], lower = -ci_datsB_sp[1,], col = cols[2])
		
		plot(x, mn_fakeA_sp, type = "b", lty = "dashed", ylim = ylim_fake, pch = 16, col = cols[1], xlab = "# of stars", ylab = "P(fake)", xaxt = "n")
		axis(1, at = x)
		points(x, mn_fakeB_sp, type = "b", lty = "dashed", pch = 16, col = cols[2])
		error.bar(x, 0, upper = ci_fakeA_sp[2,], lower = -ci_fakeA_sp[1,], col = cols[1])
		error.bar(x, 0, upper = ci_fakeB_sp[2,], lower = -ci_fakeB_sp[1,], col = cols[2])
		
	}
	
	#split subjects into thirds based on treatment effect
	diff_thirds = quantile(datsB[,3] - datsA[,3], c(1/3,2/3))
	subj_BA3_31 = which(datsB[,3] - datsA[,3] < diff_thirds[1])
	subj_BA3_32 = which(diff_thirds[1] <= datsB[,3] - datsA[,3] & datsB[,3] - datsA[,3] < diff_thirds[2])
	subj_BA3_33 = which(diff_thirds[2] <= datsB[,3] - datsA[,3])

	pdf(paste0(fpath, "Fig10_raw.pdf"), width = 7, height = 4)
		layout(matrix(1:6, nrow = 2, byrow = F))
		par(mar = c(5.1,4.1,4.1,2.1) - c(1,0,3,0))
		plot_all_subj(subj_BA3_31, c(-20,90), c(20,70))
		plot_all_subj(subj_BA3_32, c(-20,90), c(20,70))
		plot_all_subj(subj_BA3_33, c(-20,90), c(20,70))
		legend("topright", c("sold independently", "sold by manufacturer"), col = c(cols[1], cols[2]), pch = 16, bty = "n")
	dev.off()

	#split into four groups by pattern of montonicity
	subj_Binc = which(datsB[,1] <= datsB[,2] & datsB[,2] <= datsB[,3])
	subj_BinvU = which(datsB[,1] <= datsB[,2] & datsB[,2] > datsB[,3])
	subj_BU = which(datsB[,1] > datsB[,2] & datsB[,2] <= datsB[,3])
	subj_Bdec = which(datsB[,1] > datsB[,2] & datsB[,2] > datsB[,3])

	pdf(paste0(fpath, "FigA1_raw.pdf"), width = 6, height = 10)
		layout(matrix(1:8, nrow = 4, byrow = T))
		par(mar = c(5.1,4.1,4.1,2.1) - c(1,0,3,0))
		plot_all_subj(subj_Binc, c(-30,90), c(10,90))
		legend("topright", c("sold independently", "sold by manufacturer"), col = c(cols[1], cols[2]), pch = 16, bty = "n")
		plot_all_subj(subj_BinvU, c(-30,90), c(10,90))
		plot_all_subj(subj_Bdec, c(-30,90), c(10,90))
		plot_all_subj(subj_BU, c(-30,90), c(10,90))
	dev.off()


	# Simulations
	PF1_R = function(pr, pF1, PQr=1/5) { pr*pF1/(pr*pF1 + PQr*(1-pF1)) }
	PQq_Rr = function(q, r, pF1, pr, PQq=1/5, PQr=1/5) { ((q == r)*(1-pF1)*PQq + PQq*pr*pF1)/((1-pF1)*PQr + pr*pF1) }
	EQq_Rr = function(r, pF1, prs, PQq=1/5, PQr=1/5) { sum(sapply(1:5, function(q) q*PQq_Rr(q, r, pF1, prs[r], PQq, PQr))) }
	
	pdf(paste0(fpath_save, "Fig8.pdf"), width = 7, height = 3)

		rx = 3:5
		pF1_low = .1; pF1_med = .25; pF1_high = .5
		prs = c(0,0,0,.2,.8); prs = prs/sum(prs)
		dlta = 0

		layout(matrix(1:2, nrow = 1))
		par(mar = c(5.1,4.1,4.1,2.1) - c(1,0,3,0))

		plot(rx, sapply(rx, function(r) EQq_Rr(r=r, pF1=pF1_low, prs=prs) - dlta*PF1_R(prs[r], pF1=pF1_low)), type = "b", col = "dodgerblue", ylim = c(3,4.5), ylab = "simulated E(q|r)", xlab = "# of stars", pch = 16, xaxt = "n")
		axis(1, at = rx)
		points(rx, sapply(rx, function(r) EQq_Rr(r=r, pF1=pF1_med, prs=prs) - dlta*PF1_R(prs[r], pF1=pF1_med)), type = "b", col = "indianred2", pch = 16)
		points(rx, sapply(rx, function(r) EQq_Rr(r=r, pF1=pF1_high, prs=prs) - dlta*PF1_R(prs[r], pF1=pF1_high)), type = "b", col = "goldenrod1", pch = 16)
		legend("topleft", c("low fake prior", "medium fake prior", "high fake prior"), col = c(cols[1], cols[2], "goldenrod1"), pch = 16, bty = "n", pt.cex = 1, cex = .8)

		plot(rx, sapply(rx, function(r) PF1_R(pr=prs[r], pF1=pF1_low)), ylim = c(0,.8), type = "b", col = "dodgerblue", ylab = "simulated P(f = 1|r)", xlab = "# of stars", pch = 16, xaxt = "n")
		axis(1, at = rx)
		points(rx, sapply(rx, function(r) PF1_R(pr=prs[r], pF1=pF1_med)), type = "b", col = "indianred2", pch = 16)
		points(rx, sapply(rx, function(r) PF1_R(pr=prs[r], pF1=pF1_high)), type = "b", col = "goldenrod1", pch = 16)

	dev.off()

	plot_simx_fn = function(pF1_ind, pF1_ret, prs, dlta, ylmEQ = c(1,5), ylmPF = c(0,1)) {
		plot(rx, sapply(rx, function(r) EQq_Rr(r=r, pF1=pF1_ind, prs=prs) - dlta*PF1_R(prs[r], pF1=pF1_ind)), type = "b", col = "dodgerblue", ylim = ylmEQ, ylab = "simulated E(q|r)", xlab = "# of stars", pch = 16)
		points(rx, sapply(rx, function(r) EQq_Rr(r=r, pF1=pF1_ret, prs=prs) - dlta*PF1_R(prs[r], pF1=pF1_ret)), type = "b", col = "indianred2", pch = 16)
		plot(rx, sapply(rx, function(r) PF1_R(pr=prs[r], pF1=pF1_ind)), ylim = ylmPF, type = "b", col = "dodgerblue", ylab = "simulated P(f = 1|r)", xlab = "# of stars", pch = 16)
		points(rx, sapply(rx, function(r) PF1_R(pr=prs[r], pF1=pF1_ret)), type = "b", col = "indianred2", pch = 16)
	}

	pdf(paste0(fpath_save, "FigA2.pdf"), width = 6, height = 10)

		layout(matrix(1:8, nrow = 4, byrow = T))
		par(mar = c(5.1,4.1,4.1,2.1) - c(1,0,3,0))

		pF1_ind = .1; pF1_ret = .15
		prs = c(0,0,.05,.3,.65); prs = prs/sum(prs)
		dlta = 2

		plot_simx_fn(pF1_ind, pF1_ret, prs, dlta, ylmEQ = c(1.25, 4.25), ylmPF = c(0,.75))
		legend("topright", c("low fake prior", "high fake prior"), col = c(cols[1], cols[2]), pch = 16, bty = "n", pt.cex = 1, cex = 1)

		pF1_ind = .1; pF1_ret = .3
		prs = c(0,0,0,.2,.8); prs = prs/sum(prs)
		dlta = 1

		plot_simx_fn(pF1_ind, pF1_ret, prs, dlta, ylmEQ = c(1.25, 4.25), ylmPF = c(0,.75))

		pF1_ind = .1; pF1_ret = .25
		prs = c(0,0,5,32,63); prs = prs/sum(prs)
		dlta = 4

		plot_simx_fn(pF1_ind, pF1_ret, prs, dlta, ylmEQ = c(1.25, 4.25), ylmPF = c(0,.75))

		pF1_ind = .15; pF1_ret = .2
		prs = c(0,0,0,40,60); prs = prs/sum(prs)
		dlta = 5

		plot_simx_fn(pF1_ind, pF1_ret, prs, dlta, ylmEQ = c(1.25, 4.25), ylmPF = c(0,.75))

	dev.off()
